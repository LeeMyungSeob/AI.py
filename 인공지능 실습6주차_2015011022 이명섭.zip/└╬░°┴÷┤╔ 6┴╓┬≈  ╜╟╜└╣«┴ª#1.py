{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 7,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "첫번째 정수를 입력하세요: 24\n",
      "두번째 정수를 입력하세요: 5\n",
      "연산자를 입력하세요: %\n",
      "24 % 5 = 4\n"
     ]
    }
   ],
   "source": [
    "a = int(input(\"첫번째 정수를 입력하세요: \"))\n",
    "b = int(input(\"두번째 정수를 입력하세요: \"))\n",
    "c = input(\"연산자를 입력하세요: \")\n",
    "if c==\"+\":\n",
    "    print(a,c,b,\"=\",a+b)\n",
    "elif c==\"-\":\n",
    "    print(a,c,b,\"=\",a-b)\n",
    "elif c==\"/\":\n",
    "    print(a,c,b,\"=\",a/b)\n",
    "elif c==\"//\":\n",
    "    print(a,c,b,\"=\",a//b)\n",
    "elif c==\"%\":\n",
    "    print(a,c,b,\"=\",a%b)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.6"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}

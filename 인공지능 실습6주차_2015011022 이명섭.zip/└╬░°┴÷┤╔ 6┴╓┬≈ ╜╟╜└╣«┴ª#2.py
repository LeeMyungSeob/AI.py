{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 8,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "번호: 21\n",
      "국어 점수: 10\n",
      "영어 점수: 10\n",
      "수학 점수: 10\n",
      "물리 점수: 10\n",
      "============================================================\n",
      "번호\t국어\t영어\t수학\t물리\t총점\t평균\t학점\n",
      "============================================================\n",
      "21 \t 10 \t 10 \t 10 \t 10 \t 40 \t 10.0 \t F\n"
     ]
    }
   ],
   "source": [
    "Num = int(input(\"번호: \"))\n",
    "korean = int(input(\"국어 점수: \"))\n",
    "english = int(input(\"영어 점수: \"))\n",
    "math = int(input(\"수학 점수: \"))\n",
    "phy = int(input(\"물리 점수: \"))\n",
    "Sum = korean+english+math+phy\n",
    "avg = Sum/4\n",
    "if avg>=90:\n",
    "    grade = \"A+\"\n",
    "elif avg>=80:\n",
    "    grade = \"A\"\n",
    "elif avg>=70:\n",
    "    grade = \"B+\"\n",
    "elif avg>=60:\n",
    "    grade = \"B\"\n",
    "elif avg>=50:\n",
    "    grade = \"C+\"\n",
    "elif avg>=40:\n",
    "    grade=\"C\"\n",
    "elif avg>=30:\n",
    "    grade=\"D+\"\n",
    "elif avg>=20:\n",
    "    grade=\"D\"\n",
    "else:\n",
    "    grade=\"F\"\n",
    "print(\"=\"*60)\n",
    "print(\"번호\\t국어\\t영어\\t수학\\t물리\\t총점\\t평균\\t학점\")\n",
    "print(\"=\"*60)\n",
    "print(Num,\"\\t\",korean,\"\\t\",english,\"\\t\",math,\"\\t\",phy,\"\\t\",Sum,\"\\t\",avg,\"\\t\",grade)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.6"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
